create view v_d_ohlcv
            (ts_event, rtype, publisher_id, instrument_id, open, high, low, close, volume, symbol, category, minute,
             hour, week) as
SELECT ts_event,
       rtype,
       publisher_id,
       instrument_id,
       open,
       high,
       low,
       close,
       volume,
       symbol,
       "left"(symbol, 2)             AS category,
       EXTRACT(minute FROM ts_event) AS minute,
       EXTRACT(hour FROM ts_event)   AS hour,
       EXTRACT(week FROM ts_event)   AS week
FROM d_ohlcv;

alter table v_d_ohlcv
    owner to avnadmin;

